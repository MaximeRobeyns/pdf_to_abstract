<div align="center">
<h1>PDF to Abstract</h1>
</div>

A web extension to redirect from the pdf page to the abstract page for academic websites.
